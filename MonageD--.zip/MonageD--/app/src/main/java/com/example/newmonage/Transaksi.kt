package com.example.newmonage

data class Transaksi(
    val id: String,
    val tanggal: String,
    val label: String,
    val amount: Double )
